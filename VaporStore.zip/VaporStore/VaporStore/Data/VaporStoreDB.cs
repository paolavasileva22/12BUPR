﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaporStore.Data
{
    public class VaporStoreDB
    {
        public static string ConnectionString = @"Server=DESKTOP-BRJ6BRQ;Database=VaporStoreDB;Trusted_Connection=True";
    }
}
